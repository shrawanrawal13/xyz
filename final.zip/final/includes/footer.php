 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:17px;"><i class="material-icons" style="color: brown;">COPYRIGHT</i> 2017 <b >College-Notes-Gallery</b></p>
                </div>
            </div>
   </footer>