<?php include 'includes/connection.php';?>
<?php
if (isset($_POST['signup'])) {
require "gump.class.php";
$gump = new GUMP();
$_POST = $gump->sanitize($_POST); 

$gump->validation_rules(array(
  'username'    => 'required|alpha_numeric|max_len,20|min_len,4',
  'email'       => 'required|valid_email',
  'password'    => 'required|max_len,50|min_len,6',
));
$gump->filter_rules(array(
  'username' => 'trim|sanitize_string',
  'password' => 'trim',
  'email'    => 'trim|sanitize_email',
  ));
$validated_data = $gump->run($_POST);

if($validated_data === false) {
  ?>
  <center><font color="red" >   <div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">Close X</a>
                <p><strong>Alerta!</strong></p>
                 <br><br>
               <?php  echo $gump->get_readable_errors(true); ?></font></center>
            </div>';
    <?php
}
else if ($_POST['password'] !== $_POST['repassword']) 
{

   echo  '<center><div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">Close X</a>
                <p><strong>Alerta!</strong></p>
                Passwords do not match! Please try again!.
            </div></center>';
  
}
else {
      $username = $validated_data['username'];
      $checkusername = "SELECT * FROM users WHERE username = '$username'";
      $run_check = mysqli_query($conn , $checkusername) or die(mysqli_error($conn));
      $countusername = mysqli_num_rows($run_check); 
      if ($countusername > 0 ) {
       
        echo  '<center><div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">Close X</a>
                <p><strong>Alerta!</strong></p>
               Username is already taken! try a different one
            </div></center>';
  
}
$email = $validated_data['email'];
$checkemail = "SELECT * FROM users WHERE email = '$email'";
      $run_check = mysqli_query($conn , $checkemail) or die(mysqli_error($conn));
      $countemail = mysqli_num_rows($run_check); 
      if ($countemail > 0 ) {
         
        echo  '<center><div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">Close X</a>
                <p><strong>Alerta!</strong></p>Email is already taken! try a different one
              
            </div></center>';
    
}

  else {
      $email = $validated_data['email'];
      $pass = $validated_data['password'];
      $password = password_hash("$pass" , PASSWORD_DEFAULT);
      $role = $_POST['role'];
      $course = $_POST['course'];
      $gender = $_POST['gender'];
      $joindate = date("F j, Y");
      $query = "INSERT INTO users(username,email,password,role,course,gender,joindate,token) VALUES ('$username' , '$email', '$password' , '$role', '$course', '$gender' , '$joindate' , '' )";
      $result = mysqli_query($conn , $query) or die(mysqli_error($conn));
      if (mysqli_affected_rows($conn) > 0) { 
       
        echo "<script>alert('SUCCESSFULLY REGISTERED');
        window.location.href='index.php';</script>";
}
else {
  echo "<script>alert('Error Occured');
  window.location.href='index.php';</script>";

}
}
}
}
?>


<?php 
require 'includes/login.inc.php';
?>

<html>
<head>
  <title>STUDENT||DISCUSSION||FORUM||INDEXPAGE</title>

  <!--Custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/global.css">
  <!--Bootstrap CSS-->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <!--Script-->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body background="images/body.jpg">
    <!-- Navigation -->
    
      <div class="container" style="margin:5% auto;">
        <div class="col-sm-5 col-md-3">
          


<img src="images/quote.jpg" style=" opacity: 0.6; border-radius: 30px; background-image: inherit;">


                  </div>
         <div class="col-sm-5 col-md-4 pull-right">
                   <div class="row">
                   
            <form method="POST" class="form-signin" action="signup.php">
                <h3 class="text-center" style="color: white; ">SIGNUP FORM</h3>
          <input id="email" name="email" class="form-control" placeholder="example@domain.com" required="" type="email" value="<?php if(isset($_POST['signup'])) { echo $_POST['email']; } ?>"> 
          <input id="username" class="form-control" name="username" placeholder="username" requiredtabindex="2" type="text" value="<?php if(isset($_POST['signup'])) { echo $_POST['username']; } ?>"> 
          <input type="password" placeholder="Password" name="password" class="form-control" required>
          <input type="password" placeholder="Re-enter Password" name="repassword" class="form-control" required> <select class="form-control" name="role">
            <option>I am a</option>
            <option value="teacher">Teacher</option>
            <option value="student">Student</option>
            </select>
            <select class="form-control" name="course">
            <option>I Study/Teach</option>
            <option value="Computer Science">Computer Sc Engineering</option>
            <option value="Electrical">Electrical Engineering</option>
            <option value="Mechanical">Mechanical Engineering</option>
            </select>
              <select class="form-control" name="gender"required>
                <option>Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
              <button type="submit" class="btn btn-success" name="signup">Sign up</button>
              

              
              
            </form>
        </div>
      </div>
    </div>

    





<style>
.footer {
   position:fixed;
   left: 0;
   bottom: 0.5px;
   width: 100%;
   background-color: #333;
   color: white;
   height: 45px;
   text-align: center;
   opacity: 0.8;

}

</style>
<div class="footer">
  <p>Copyright 2018 BE.CMP EEC All right Reserved </p>
</div>





</body>
</html>